package com.app.tiffin.dtos;

import java.util.Date;
import java.util.List;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.app.tiffin.entities.Order;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/*@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor*/
public class OrderDto {

	private int orderId;
	private int userId;
	@Temporal(TemporalType.TIMESTAMP)
	private Date orderDate;
	private int totalAmount;
	private int tiffinId;
	public OrderDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderDto(int orderId, int userId, Date orderDate, int totalAmount, int tiffinId) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.orderDate = orderDate;
		this.totalAmount = totalAmount;
		this.tiffinId = tiffinId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	public int getTiffinId() {
		return tiffinId;
	}
	public void setTiffinId(int tiffinId) {
		this.tiffinId = tiffinId;
	}
	@Override
	public String toString() {
		return "OrderDto [orderId=" + orderId + ", userId=" + userId + ", orderDate=" + orderDate + ", totalAmount="
				+ totalAmount + ", tiffinId=" + tiffinId + "]";
	}
	
	
	

}
