package com.app.tiffin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiffinManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiffinManagementSystemApplication.class, args);
	}

}
