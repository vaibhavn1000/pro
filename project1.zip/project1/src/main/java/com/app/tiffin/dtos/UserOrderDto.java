package com.app.tiffin.dtos;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class UserOrderDto {

	private int order_id;
	private int user_id;
	private Date start_date;
	private Date end_date;
	private int total_days;
	private int total_amount;
	private int tiffin_id;
	
}
