package com.app.tiffin.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/*
@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor*/

@Entity
@Table(name = "tiffin_details")
public class TiffinDetail 
{
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "tiffin_id")
	private int tiffinId;

	@Column(name = "tiffin_name")
	private String tiffinName;

	@Column(name = "tiffin_price")
	private double tiffinPrice;

	@Column(name = "description")
	private String description;

	@OneToMany(mappedBy = "tiffinDetails", cascade = CascadeType.ALL)
	private List<Order> order;
	
	public TiffinDetail(int tiffinId) {
		this.tiffinId=tiffinId;
	}

	public TiffinDetail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getTiffinId() {
		return tiffinId;
	}

	public void setTiffinId(int tiffinId) {
		this.tiffinId = tiffinId;
	}

	public String getTiffinName() {
		return tiffinName;
	}

	public void setTiffinName(String tiffinName) {
		this.tiffinName = tiffinName;
	}

	public double getTiffinPrice() {
		return tiffinPrice;
	}

	public void setTiffinPrice(double tiffinPrice) {
		this.tiffinPrice = tiffinPrice;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "TiffinDetail [tiffinId=" + tiffinId + ", tiffinName=" + tiffinName + ", tiffinPrice=" + tiffinPrice
				+ ", description=" + description + ", order=" + order + "]";
	}
	
	
	
}
