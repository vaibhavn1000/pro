package com.app.tiffin.dtos;

import java.util.Objects;

//import org.springframework.beans.BeanUtils;

import com.app.tiffin.entities.TiffinDetail;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/*@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor*/
public class TiffinFormDto 
{
	private int tiffinId;
	private String tiffinName;
	private double tiffinPrice;
	private String description;
	public TiffinFormDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TiffinFormDto(int tiffinId, String tiffinName, double tiffinPrice, String description) {
		super();
		this.tiffinId = tiffinId;
		this.tiffinName = tiffinName;
		this.tiffinPrice = tiffinPrice;
		this.description = description;
	}
	public int getTiffinId() {
		return tiffinId;
	}
	public void setTiffinId(int tiffinId) {
		this.tiffinId = tiffinId;
	}
	public String getTiffinName() {
		return tiffinName;
	}
	public void setTiffinName(String tiffinName) {
		this.tiffinName = tiffinName;
	}
	public double getTiffinPrice() {
		return tiffinPrice;
	}
	public void setTiffinPrice(double tiffinPrice) {
		this.tiffinPrice = tiffinPrice;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "TiffinFormDto [tiffinId=" + tiffinId + ", tiffinName=" + tiffinName + ", tiffinPrice=" + tiffinPrice
				+ ", description=" + description + "]";
	}
	
	
	
	
//	public static TiffinDetail toEntity(TiffinFormDto dto) {
//		TiffinDetail entity=new TiffinDetail();
//		BeanUtils.copyProperties(dto, entity, "imageName");
//		return entity;
//	}
	
	
	
}
